// 导入react模块（组件）中的默认组件，并且命名为React
import React from 'react';

import {
  Tab,
  TextField,
  makeStyles,
  Button,
} from '@material-ui/core';

import { 
  TabContext, 
  TabList, 
  TabPanel 
} from '@material-ui/lab';


import axios from 'axios';

// 渲染页面 用usestate 使用一些set函数进行赋值
const Index = ({ children }) => {
  // 切换功能
  const [tabIndex, setTabIndex] = React.useState('getlocalweather');
  // 暂存内容
  const [text, setText] = React.useState();
  const [sentiment, setSentiment] = React.useState();

  // 在js里面写css的方法
  const useStyles = makeStyles((theme) => ({
    cheny : {
      width: '100%',
      height: '100%',
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'center',
      alignItems: 'center',

      // 标签页(组件布局)
      '& .tabs': {
        width: '100%',
        borderBottom: `1px solid ${theme.palette.divider}`,
      },

      // 标签页
      '& .tab': {
        boxSizing: 'border-box',
        width: '50%',
        flexGrow: 1,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',

        // 按钮标签
        '& .button': {
          marginTop: theme.spacing(4),
          marginBottom: theme.spacing(4),
        },

        // 天气预报
        '& .sentiment-wrapper': {
          flexGrow: 1,
          maxWidth: '80%',
          height: 0,
          display: 'flex',
          alignItems: 'center',

          // 天气
          '& .sentiment': {
            height: 0,
            borderRadius: '50%',
            transition: '0.5s',
            paddingBottom: '100%',
            position: 'relative',

            // 天气文本
            '& .sentiment-text': {
              position: 'absolute',
              top: 0,
              bottom: 0,
              left: 0,
              right: 0,
              color: 'white',
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center',
              fontSize: 24,
            },     

            '& .empty': {
              width: '100%',
              flexGrow: 1,
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center',
              fontSize: 24,
              // text.secondary:文本辅助
              color: theme.palette.text.secondary,
            },
          },
        },
      },
    },
  }));
  // 调用上述的创建网页样式用的code
  const classes = useStyles();

  // 切换标签（功能）时清空所有数据
  const handleTabChange = (event, value) => {
    // 全部都是需要调用的函数
    // 设置切换标签页
    setTabIndex(value);
    // 清除临时变量 用了usestate不会自动清除，需要手动清除
    setText();
    setSentiment();
  };

  // 从 Django 获取天气预报结果
  const getSentiment = () => {
    if (text) {
      // { text } json对象
      // json对象在js里面如果出现xx=xx 可以简写成{ text }
      axios.post('http://127.0.0.1:8000/getlocalweather', { citycode:text  }).then((res) => {
        if (res.status === 200) {
          setSentiment("你查询的当地天气信息如下："+"\n"+"\n"+"省市："+res.data.province+res.data.city+"\n"+"城市："+res.data.city+"\n"+"编码："+res.data.adcode+"\n"+"天气："+res.data.weather+"\n"+"气温："+res.data.temperature+"\n"+"风向："+res.data.winddirection+"\n"+"风力："+res.data.windpower+"\n"+"湿度："+res.data.humidity+"\n"+"报告时间："+res.data.reporttime);
          console.log(res.data)
        }
      })
    }
  }

  return (
    <div className={classes.cheny}>
      <TabContext value={tabIndex}>
        <TabList
          className="tabs"
          variant="fullWidth"
          indicatorColor="primary"
          onChange={handleTabChange}
        >
          <Tab label="城市天气预报" value="getlocalweather" />
        </TabList>
        {tabIndex === 'getlocalweather' && <TabPanel value="getlocalweather" className="tab">
          <TextField
            fullWidth
            multiline
            rows={2}
            variant="outlined"
            placeholder="请输入城市编码"
            onChange={(event) => setText(event.target.value)}
          />
          <p></p>
          <a href="http://www.ip33.com/area_code.html">
            城市编码查询
          </a>
          <Button
            fullWidth
            variant="contained"
            className="button"
            color="primary"
            onClick={getSentiment}
          >
            天气查询
          </Button>
          <TextField
            fullWidth
            multiline
            disabled
            rows={11}
            variant="outlined"
            placeholder="等待结果..."
            value={sentiment}
          />
          </TabPanel>}
      </TabContext>
    </div>
  );
};

export default Index;
