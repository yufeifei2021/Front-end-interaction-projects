# 处理url，将访问的URL映射到处理函数
from django.contrib import admin # 利用Django自带的后台管理系统
from django.urls import path # 用来对访问url进行解析
# . ：从当前文件夹import
# * ：从库中导入所有的包
from . import views

# Django 项目的路由配置，对应的路径会被映射到对应的函数
urlpatterns = [
  path('getlocalweather', views.getlocalweather)
]
