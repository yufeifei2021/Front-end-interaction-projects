import json
import requests
from django.http import HttpResponse


# cred = credential.Credential("AKIDhDTTCepjMipfFXZLq41h6E5fy0lFSP5V", "B5qPhiSv72g3A0Zrte8KFuIODl22lDOH") 
# httpProfile = HttpProfile()
# httpProfile.endpoint = "nlp.tencentcloudapi.com"

# clientProfile = ClientProfile()
# clientProfile.httpProfile = httpProfile
# client = nlp_client.NlpClient(cred, "ap-guangzhou", clientProfile) 

# def sentiment_analysis(request):
#   # request.body ：post里面携带的数据 拿到字符串，本身是json形式，先解析成python字典
#   # json.loads ：解析成字典 .get ：从字典中 将text（前端请求得到的）值取出
#   text = json.loads(request.body).get('text')
#   # print(text)
#   # 将从前端得到的text发送给腾讯云 再将腾讯云返回的结果返回给前端
#   req = models.SentimentAnalysisRequest()
#   params = {
#     "Text": text
#   }
#   req.from_json_string(json.dumps(params))
#   resp = client.SentimentAnalysis(req)
#   print(resp)
#   return HttpResponse(resp)

def getlocalweather(request):
    url = "https://restapi.amap.com/v3/weather/weatherInfo"
    key = 'e049d649ad2eee12a967f37c8e6dcaf7'
    city = json.loads(request.body).get('citycode')
    # print(city)
    # print(request)
    data = {'key': key, "city": city }
    req = requests.post(url, data)
    # print(req)  
    info = req.json()
    # print()
    # print(info.get("lives"))
    print(info.get("lives")[0])
    # newinfo = info['lives'][0]
    # print(newinfo)
    # print()
    # print("你查询的当地天气信息如下：")
    # print("省市：",newinfo['province']+newinfo['city'])
    # print("城市：", newinfo['city'])
    # print("编码：", newinfo['adcode'])
    # print("天气：", newinfo['weather'])
    # print("气温：", newinfo['temperature']+'℃')
    # print("风向：", newinfo['winddirection'])
    # print("风力：", newinfo['windpower'])
    # print("湿度：", newinfo['humidity'])
    # print("报告时间：", newinfo['reporttime'])
    
    return HttpResponse(json.dumps(info.get("lives")[0]))


