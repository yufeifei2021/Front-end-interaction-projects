from django.db import models

# Create your models here.

class Blog(models.Model):
    title = models.CharField(max_length = 120)
    content = models.TextField()
    user_count = models.IntegerField(default = 0)

    def _str_(self):
        return self.title
