from django.shortcuts import render
from rest_framework import viewsets
import rest_framework # 新加
from .serializers import BlogSerializer # 新加
from .serializers import *
from .models import Blog # 新加
from rest_framework.decorators import action # 新加
from rest_framework.response import Response # 新加

# Create your views here.
class BlogView(viewsets.ModelViewSet): # 新加
    # 指定序列化器：把数据库中的函数 转化为可以读取的函数
    serializer_class = BlogSerializer # 新加 
    # 指定哪些数据会参加增删改查 Blog.objects：blog的所有数据
    queryset = Blog.objects.all() # 新加 

    @action(detail = True) # detail是model对应的id
    def count(self, request, pk): # pk是对应模型的id
        blog = Blog.objects.get(pk = pk) # 找出这个博文
        blog.user_count = blog.user_count +1
        blog.save()
        return Response({
            'success': True,
            '当前点赞数': blog.user_count
        })    
          

