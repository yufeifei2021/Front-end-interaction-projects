from django.contrib import admin
from django.urls import path,include # 新加
from rest_framework import routers # 新加
from blog import views # 新加

router = routers.DefaultRouter() # 新加
router.register(r'blogs', views.BlogView, 'blog') # 新加

urlpatterns = [
    path('admin/', admin.site.urls),
    # 新加 include不会中途中断执行
    path('api/', include(router.urls))
]
