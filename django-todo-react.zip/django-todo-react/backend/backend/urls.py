# 完成API构建的最后一步
'''
我们现在可以在Todo模型上执行CRUD操作
路由器类允许我们进行以下查询：
1./todos/ 这将返回所有Todo项的列表
（可以在此处完成Create和Read操作）

2./todos/id 这将使用id主键返回单个Todo项
（可以在此处执行Update和Delete操作）
'''

from django.contrib import admin
from django.urls import path, include 
from rest_framework import routers 
from todo import views 

router = routers.DefaultRouter() 
# 表示把todo下的子路径委托给views.TodoView托管
router.register(r'todos', views.TodoView, 'todo')

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/', include(router.urls)) 
]