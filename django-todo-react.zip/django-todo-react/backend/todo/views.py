from django.shortcuts import render

# Create your views here.
from rest_framework import viewsets
from .serializers import TodoSerializer
from .models import Todo

# 视图集基类默认提供CRUD操作的实现
# 我们要做的是指定序列化程序类和查询集
class TodoView(viewsets.ModelViewSet):
    # serializer可以帮助生成增删改查的函数、相关url等生成好
    serializer_class = TodoSerializer 
    queryset = Todo.objects.all()

# 使用了drf:
# 1.立刻监听（持续） 某个端口 这里不用等用户访问
# 2.当有用户发送请求 就会进行路由匹配 根据url映射成具体的函数，然后通过这被drf托管的具体函数 操作数据库并返回给用户

# 没有drf：监听端口 路由匹配 匹配到自己写的处理函数 将其解析 根据请求内容返回结果

