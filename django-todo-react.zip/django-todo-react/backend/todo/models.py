from django.db import models

# Create your models here.


# 新加
# 改变了Todo model，现在需要对数据做一个迁移，以确保数据库改变。
# 1 python3 manage.py makemigrations todo
# 2 python manage.py migrate todo

'''
Todo类中描述了三个属性：
1.Title
2.Description
3.Completed
'''

class Todo(models.Model):
    title = models.CharField(max_length = 120)
    description = models.TextField()
    completed = models.BooleanField()

    def _str_(self):
        return self.title

