from rest_framework import serializers
from .models import Todo

# 指定要使用的模型以及我们要转换为JSON的字段
# 将模型设置成可以增删改查的函数
class TodoSerializer(serializers.ModelSerializer):
    class Meta:
        model = Todo
        fields = ('id', 'title', 'description', 'completed')


