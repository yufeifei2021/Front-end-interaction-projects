import React, { Component } from "react";
import Modal from "./components/Modal";//加载弹窗
import axios from "axios";

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      viewCompleted: false,
      //暂存todo的值
      activeItem: {
        title: "",
        description: "",
        completed: false
      },
      todoList: []
    };
  }
  //跟响应有关 生命周期函数，页面刚刚加载需要进行的工作，对应函数组件中的useEffect
  //useEffect:1.监听全部变量；2.监听部分变量；3.只在页面初始化时执行(...,[])
  //...是function 是监听变量时需要的函数
  componentDidMount() {
    this.refreshList();
  }
  refreshList = () => {
    //像后端发送请求 
    //JS语言：try-catch:异常处理
    //then().catch():异步 
    //同步：一行代码执行结束才会执行下一行；
    //异步：不需要等上一行执行完，只要上一行开始执行，下一行就可以执行操作
    //常理说，异步操作无法立刻返回结果（res = axios.get ... 不行，python中可以）
    //请求时间可能很长，或成功或失败，所以使用异步操作
    axios
      .get("http://localhost:8000/api/todos/")
      .then(res => this.setState({ todoList: res.data }))//成功 res结果
      .catch(err => console.log(err));//失败 err结果
  };
  //修改viewCompleted的状态 true或false
  displayCompleted = status => {
    if (status) {
      //viewCompleted是一个标志，true：前端只把已完成的todo过滤显示，false：相反
      return this.setState({ viewCompleted: true });
    }
    return this.setState({ viewCompleted: false });
  };
  //定义renderTabList函数式组件（组件里面可以嵌套组件）
  //（渲染按钮）
  renderTabList = () => {
    return (
      <div className="my-5 tab-list">
        {/* 设置为true */}
        <span
          onClick={() => this.displayCompleted(true)}
          className={this.state.viewCompleted ? "active" : ""}
        >
          complete
        </span>
        {/* 设置为false */}
        <span
          onClick={() => this.displayCompleted(false)}
          className={this.state.viewCompleted ? "" : "active"}
        >
          Incomplete
        </span>
      </div>
    );
  };
  //函数式组件（渲染整个todo）
  renderItems = () => {
    // 解构赋值:如果变量名和后面的属性名一样就可以使用71行写法
    //等价于： const viewCompleted = this.state.viewCompleted
    const { viewCompleted } = this.state;
    //this.state.todoList包含了所有的todo，不区分是否标志化
    //对this.state.todoList数组进行filter操作

    //76-81行：从todolist中筛选出已完成/未完成的项目
    const newItems = this.state.todoList.filter(
      // filter的参数是一个函数
      // 对于todolist里面的每一项，使用这个函数处理后
      // 返回值为真值的项目（非0，非null，非undefined，非false），组合起来成为一个新数组
      item => item.completed === viewCompleted
    );
    //类似filter，map也接收一个参数，也是函数
    //对于数组newItems的每一项，依次进行map操作，返回值组合起来 作为一个新数组
    //将数据渲染成自己设置的元素
    return newItems.map(item => (
      <li
        key={item.id}
        className="list-group-item d-flex justify-content-between align-items-center"
      >
      {/*li:列表中的一项
        ol:有序 有数字 ；ul:无序 有·*/}

        {/*div:区块划分，换行
          span:行内元素，不换行*/}
        <span
          className={`todo-title mr-2 ${
            this.state.viewCompleted ? "completed-todo" : ""
          }`}
          title={item.description}
        >
          {item.title}
        </span>
        <span>
          <button
            onClick={() => this.editItem(item)}
            className="btn btn-secondary mr-2"
          >
            {" "}
            Edit{" "}
          </button>
          <button
            onClick={() => this.handleDelete(item)}
            className="btn btn-danger"
          >
            Delete{" "}
          </button>
        </span>
      </li>
    ));
  };
  //弹窗的开关
  toggle = () => {
    this.setState({ modal: !this.state.modal });
    // 每次取反
  };
  //提交表单
  handleSubmit = item => {
    this.toggle();
    //针对编辑、创建进行不同处理
    if (item.id) {
      // .put 仅改    .post 增删改
      axios
        .put(`http://localhost:8000/api/todos/${item.id}/`, item)
        .then(res => this.refreshList());
      return;
    }
    axios
      .post("http://localhost:8000/api/todos/", item)
      .then(res => this.refreshList());
  };
  //删除 类似编辑、创建
  handleDelete = item => {
    //.delete 专门用于删除的请求
    axios
      .delete(`http://localhost:8000/api/todos/${item.id}`)
      .then(res => this.refreshList());
  };
  //弹出弹窗 进行创建
  createItem = () => {
    //先清空内容
    const item = { title: "", description: "", completed: false };
    this.setState({ activeItem: item, modal: !this.state.modal });
  };
  //先赋值弹出弹窗
  editItem = item => {
    this.setState({ activeItem: item, modal: !this.state.modal });
  };

  render() {
    return (
      <main className="content">
        <h1 className="text-white text-uppercase text-center my-4">Todo app</h1>
        <div className="row ">
          <div className="col-md-6 col-sm-10 mx-auto p-0">
            <div className="card p-3">
              <div className="">
                <button onClick={this.createItem} className="btn btn-primary">
                  Add task
                </button>
              </div>
              {this.renderTabList()}
              <ul className="list-group list-group-flush">
                {this.renderItems()}
              </ul>
            </div>
          </div>
        </div>
        {this.state.modal ? (
          <Modal
            activeItem={this.state.activeItem}
            toggle={this.toggle}
            onSave={this.handleSubmit}
          />
        ) : null}
      </main>
    );
  }
}
export default App;
